# -*- coding: utf-8 -*-
"""
Created on Thu Nov  1 13:14:46 2018

@author: harip
"""

from sklearn.cluster import KMeans
import pandas as pd
import numpy as np
import csv
import math
import matplotlib.pyplot
from matplotlib import pyplot as plt

diff_pair=r'\diffn_pairs.csv'
same_pair=r'\same_pairs.csv'

def dataset(samediffpair,datatotake=0,type='default'):
    human_folder=r'HumanObserved-Features-Data'
    gsc_folder=r'GSC-Features-Data'
    human_features=r'\HumanObserved-Features-Data.csv'
    gsc_features=r'\GSC-Features.csv'
    
    if(type=='HumanObserved'):
        folder=human_folder
        file=human_features
    else:
        folder=gsc_folder
        file=gsc_features
    
    #read files
    readfromfile=pd.read_csv(folder+file)
    samepairdata=pd.read_csv(folder+samediffpair)
    
    if(datatotake>1):
        samepairdata=samepairdata.sample(n=datatotake)
    
    #get data for image A
    imgA=pd.merge(samepairdata,readfromfile,left_on='img_id_A',right_on='img_id',how='left')
    imgA.drop(imgA.columns[2:5],axis=1,inplace=True)
        
    #get data for image B
    imgB=pd.merge(samepairdata,readfromfile,left_on='img_id_B',right_on='img_id',how='left')    
    target=imgB[['img_id_B','target']]
    
    imgB.drop(imgB.columns[0],axis=1,inplace=True)
    imgB.drop(imgB.columns[1:4],axis=1,inplace=True)
    
    #merge image A, image B and target data
    finalmerged=pd.merge(imgA,imgB.drop_duplicates(),on='img_id_B',how='left')
    finalmerged=pd.merge(finalmerged,target.drop_duplicates(),on='img_id_B',how='left')

    return finalmerged

def data_method(method):
        
    same_writer=dataset(same_pair,datatotake=0,type=method)
    diff_writer=dataset(diff_pair,datatotake=791,type=method)
    entireset=same_writer.append(diff_writer,ignore_index=True)
    entireset=entireset.reindex(np.random.permutation(entireset.index))
    entireset.sort_index(inplace=True)    
    return entireset;

method='HumanObserved'
human=data_method(method)

method='gsc'
gsc=data_method(method)


#**** human observed*****
#create target set from dataframe
target_human=human['target']
target_human_numpy=target_human.as_matrix() #target value for human
#drop img columns and target from dataframe
human=human.drop(columns=['img_id_A','img_id_B','target'])
#save dataframe as numpy matrix
numpy_matrix=human.as_matrix()
numpy_matrix_transpose=numpy_matrix.transpose() #concatenated tranposed features data

#split numpy array and substract values
a,b=np.hsplit(numpy_matrix,2)
c=np.subtract(b,a)
#save as numpy matrix tranpose
numpy_matrix_sub_transpose=np.transpose(c) #subtracted tranposed features data



method='gsc'
gsc=data_method(method)

#*****GSC dataset******
#create target set from dataframe
target_gsc=gsc['target']
target_gsc_numpy=target_gsc.as_matrix() #target values for gsc
#drop img columns and target from dataframe
gsc=gsc.drop(columns=['img_id_A','img_id_B','target'])
gsc_for_sub=gsc
gsc_for_sub=gsc_for_sub.as_matrix()
#drop columns*********
gsctest=gsc.loc[:,(gsc!=0).any(axis=0)]
#convert data frame to numpy
#*********end drop columns*******
#save dataframe as numpy matrix
numpy_matrix_gsc=gsctest.as_matrix()
numpy_matrix_transpose_gsc=numpy_matrix_gsc.transpose() #concatenated transposed features data

#split numpy array and substract values
x,y=np.hsplit(gsc_for_sub,2)
z=np.subtract(y,x)
#drop columns*********
test1=pd.DataFrame(z)
test1=test1.loc[:,(test1!=0).any(axis=0)]
#convert data frame to numpy
test2=test1.as_matrix()
#*********end drop columns*******
#save as numpy matrix transpose
numpy_matrix_transpose_sub_gsc=np.transpose(test2) #subtracted tranposed features data

from sklearn.cluster import KMeans
import numpy as np
import csv
import math
import matplotlib.pyplot
from matplotlib import pyplot as plt


# In[6]:


maxAcc = 0.0
maxIter = 0
C_Lambda = 0.03
TrainingPercent = 80  #Training Dataset is 80% of the LeToR dataset
ValidationPercent = 10  #Validation Dataset is 10% of the LeToR dataset
TestPercent = 10   #Testing Dataset is 10% of the LeToR dataset
M = 10  # No. of basis Functions
PHI = []  #PHI represents the features
IsSynthetic = False


# In[158]:

def GetTargetVector(filePath):
    t = []
    with open(filePath, 'rU') as f:
        reader = csv.reader(f)
        for row in reader:  
            #append row[0] to an empty list t
            t.append(int(row[0]))
    #print("Raw Training Generated..")
    return t

 #opening the Querylevelnorm_X.csv file in read mode
 #Generate Data Matrix
def GenerateRawData(filePath, IsSynthetic):    
    dataMatrix = [] 
    with open(filePath, 'rU') as fi:
        reader = csv.reader(fi)
        for row in reader:
            dataRow = []
            for column in row:
                dataRow.append(float(column))
            dataMatrix.append(dataRow)   
    
    if IsSynthetic == False :
        dataMatrix = np.delete(dataMatrix, [5,6,7,8,9], axis=1)
    dataMatrix = np.transpose(dataMatrix)     
    #print ("Data Matrix Generated..")
    return dataMatrix

def GenerateTrainingTarget(rawTraining,TrainingPercent = 80):
    TrainingLen = int(math.ceil(len(rawTraining)*(TrainingPercent*0.01)))
    t           = rawTraining[:TrainingLen]
    #print(str(TrainingPercent) + "% Training Target Generated..")
    return t

def GenerateTrainingDataMatrix(rawData, TrainingPercent = 80):
    T_len = int(math.ceil(len(rawData[0])*0.01*TrainingPercent))
    d2 = rawData[:,0:T_len]
    #print(str(TrainingPercent) + "% Training Data Generated..")
    return d2

def GenerateValData(rawData, ValPercent, TrainingCount): 
    valSize = int(math.ceil(len(rawData[0])*ValPercent*0.01))
    V_End = TrainingCount + valSize
    dataMatrix = rawData[:,TrainingCount+1:V_End]
    #print (str(ValPercent) + "% Val Data Generated..")  
    return dataMatrix

def GenerateValTargetVector(rawData, ValPercent, TrainingCount): 
    valSize = int(math.ceil(len(rawData)*ValPercent*0.01))
    V_End = TrainingCount + valSize
    t =rawData[TrainingCount+1:V_End]
    #print (str(ValPercent) + "% Val Target Data Generated..")
    return t
 #Method to generate Big Sigma
def GenerateBigSigma(Data, MuMatrix,TrainingPercent,IsSynthetic):
    BigSigma    = np.zeros((len(Data),len(Data)))
    DataT       = np.transpose(Data)
    TrainingLen = math.ceil(len(DataT)*(TrainingPercent*0.01))        
    varVect     = []
    for i in range(0,len(DataT[0])):
        vct = []
        for j in range(0,int(TrainingLen)):
            vct.append(Data[i][j])    
        varVect.append(np.var(vct))
    
    for j in range(len(Data)):
        #Diagonal elements BigSigma[j][j] contain variances
        BigSigma[j][j] = varVect[j]
    if IsSynthetic == True:
        BigSigma = np.dot(3,BigSigma)
    else:
        BigSigma = np.dot(200,BigSigma)
    ##print ("BigSigma Generated..")
    return BigSigma
 #method to get scalar values from the input
def GetScalar(DataRow,MuRow, BigSigInv):  
    R = np.subtract(DataRow,MuRow)
    T = np.dot(BigSigInv,np.transpose(R))  
    L = np.dot(R,T)
    return L
 #Method to generate Guassian Radial basis function φj (x)
def GetRadialBasisOut(DataRow,MuRow, BigSigInv):    
    phi_x = math.exp(-0.5*GetScalar(DataRow,MuRow,BigSigInv))
    return phi_x

 #Method to generate φ matrix
def GetPhiMatrix(Data, MuMatrix, BigSigma, TrainingPercent = 80):
    DataT = np.transpose(Data)
    TrainingLen = math.ceil(len(DataT)*(TrainingPercent*0.01))         
    PHI = np.zeros((int(TrainingLen),len(MuMatrix))) 
    BigSigInv = np.linalg.inv(BigSigma)
    for  C in range(0,len(MuMatrix)):
        for R in range(0,int(TrainingLen)):
            PHI[R][C] = GetRadialBasisOut(DataT[R], MuMatrix[C], BigSigInv)
    #print ("PHI Generated..")
    return PHI

 #Method to generate closed form solution using the formula w∗ = (λI + ΦTΦ)−1ΦTt
def GetWeightsClosedForm(PHI, T, Lambda):
    Lambda_I = np.identity(len(PHI[0]))
    for i in range(0,len(PHI[0])):
        Lambda_I[i][i] = Lambda
    PHI_T       = np.transpose(PHI)
    PHI_SQR     = np.dot(PHI_T,PHI)
    PHI_SQR_LI  = np.add(Lambda_I,PHI_SQR)
    PHI_SQR_INV = np.linalg.inv(PHI_SQR_LI)
    INTER       = np.dot(PHI_SQR_INV, PHI_T)
    W           = np.dot(INTER, T)
    ##print ("Training Weights Generated..")
    return W
 #Method to generate φ matrix
def GetPhiMatrix(Data, MuMatrix, BigSigma, TrainingPercent = 80):
    DataT = np.transpose(Data)
    TrainingLen = math.ceil(len(DataT)*(TrainingPercent*0.01))         
    PHI = np.zeros((int(TrainingLen),len(MuMatrix))) 
    BigSigInv = np.linalg.inv(BigSigma)
    for  C in range(0,len(MuMatrix)):
        for R in range(0,int(TrainingLen)):
            PHI[R][C] = GetRadialBasisOut(DataT[R], MuMatrix[C], BigSigInv)
    #print ("PHI Generated..")
    return PHI
 #Method to get Valdidation Test out
def GetValTest(VAL_PHI,W):
    Y = np.dot(W,np.transpose(VAL_PHI))
    ##print ("Test Out Generated..")
    return Y
 #Method to get Erms usign formula
def GetErms(VAL_TEST_OUT,ValDataAct):
    sum = 0.0
    t=0
    accuracy = 0.0
    counter = 0
    val = 0.0
    for i in range (0,len(VAL_TEST_OUT)):
        sum = sum + math.pow((ValDataAct[i] - VAL_TEST_OUT[i]),2)
        if(int(np.around(VAL_TEST_OUT[i], 0)) == ValDataAct[i]):
            counter+=1
    accuracy = (float((counter*100))/float(len(VAL_TEST_OUT)))
    ##print ("Accuracy Generated..")
    ##print ("Validation E_RMS : " + str(math.sqrt(sum/len(VAL_TEST_OUT))))
    return (str(accuracy) + ',' +  str(math.sqrt(sum/len(VAL_TEST_OUT))))


# ## Fetch and Prepare Dataset

# In[127]:




def logistics(RawTarget,RawData,c):
    TrainingTarget = np.array(GenerateTrainingTarget(RawTarget,TrainingPercent))
    TrainingData   = GenerateTrainingDataMatrix(RawData,TrainingPercent)
    
    
    
    # ## Prepare Validation Data
    
    # In[129]:
    
     #Preparing validation data by calling respective methods
    ValDataAct = np.array(GenerateValTargetVector(RawTarget,ValidationPercent, (len(TrainingTarget))))
    ValData    = GenerateValData(RawData,ValidationPercent, (len(TrainingTarget)))
    
    
    
    # ## Prepare Test Data
    
    # In[130]:
    
     #Preparing Test data by calling respective methods
    TestDataAct = np.array(GenerateValTargetVector(RawTarget,TestPercent, (len(TrainingTarget)+len(ValDataAct))))
    TestData = GenerateValData(RawData,TestPercent, (len(TrainingTarget)+len(ValDataAct)))
    
    
    
    # ## Closed Form Solution [Finding Weights using Moore- Penrose pseudo- Inverse Matrix]
    
    # In[155]:
    
     #Closed form solution starts here
    ErmsArr = []
    AccuracyArr = []
    
    kmeans = KMeans(n_clusters=M, random_state=0).fit(np.transpose(TrainingData))
    Mu = kmeans.cluster_centers_
    
    BigSigma     = GenerateBigSigma(RawData, Mu, TrainingPercent,IsSynthetic)
    TRAINING_PHI = GetPhiMatrix(RawData, Mu, BigSigma, TrainingPercent)
    W            = GetWeightsClosedForm(TRAINING_PHI,TrainingTarget,(C_Lambda)) 
    TEST_PHI     = GetPhiMatrix(TestData, Mu, BigSigma, 100) 
    VAL_PHI      = GetPhiMatrix(ValData, Mu, BigSigma, 100)
    
    
    # In[156]:
    
    
    
    
    # ## Finding Erms on training, validation and test set 
    
    # In[159]:
    
    
    TR_TEST_OUT  = GetValTest(TRAINING_PHI,W)
    VAL_TEST_OUT = GetValTest(VAL_PHI,W)
    TEST_OUT     = GetValTest(TEST_PHI,W)
    
    TrainingAccuracy   = str(GetErms(TR_TEST_OUT,TrainingTarget))
    ValidationAccuracy = str(GetErms(VAL_TEST_OUT,ValDataAct))
    TestAccuracy       = str(GetErms(TEST_OUT,TestDataAct))
    
    
    # In[160]:
    
    
    print ('UBITname      = KBASKARA')
    print ('Person Number = 50288944')
    
    
    #closed form solution ends here
    # ## Gradient Descent solution for Linear Regression
    
    # In[138]:
    
    
    
    
    # In[ ]:
    
    
    
    def epower(value):
        
        e=1+math.exp(-value)
        
        return 1/e
    
    def sigmoid(W_Now,TRAINING_PHI):
        exp=np.dot(np.transpose(W_Now),TRAINING_PHI[i])
        return exp
    
    W_Now        = np.dot(220, W)
    La           = 2
    learningRate = 0.01
    L_Erms_Val   = []
    L_Erms_TR    = []
    L_Erms_Test  = []

   
    #log implementation for the ;
    for i in range(0,900):
        
        #print ('---------Iteration: ' + str(i) + '--------------')
        
        exp=sigmoid(W_Now,TRAINING_PHI)
        #log value is y cap
        log_value=epower(exp)
        
        c_log_value=c[i]*log_value
        
        one_minus_y=1-c[i]
        if(1-log_value==0):
            log_one_minus_ycap=0
        else:    
            log_one_minus_ycap=np.log(1-log_value)
            
        L=c_log_value + (one_minus_y*log_one_minus_ycap)
    
        #Delta_E_D     = -np.dot((c_log_value - np.dot(np.transpose(W_Now),TRAINING_PHI[i])),TRAINING_PHI[i])
        Delta_E_D     = -np.dot(L,TRAINING_PHI[i])
        La_Delta_E_W  = np.dot(La,W_Now)
        Delta_E       = np.add(Delta_E_D,La_Delta_E_W)    
        Delta_W       = -np.dot(learningRate,Delta_E)
        W_T_Next      = W_Now + Delta_W
        W_Now         = W_T_Next
        
        #-----------------TrainingData Accuracy---------------------#
        TR_TEST_OUT   = GetValTest(TRAINING_PHI,W_T_Next) 
        Erms_TR       = GetErms(TR_TEST_OUT,c)
        L_Erms_TR.append(float(Erms_TR.split(',')[1]))
        #-----------------ValidationData Accuracy---------------------#
        VAL_TEST_OUT  = GetValTest(VAL_PHI,W_T_Next) 
        Erms_Val      = GetErms(VAL_TEST_OUT,ValDataAct)
        L_Erms_Val.append(float(Erms_Val.split(',')[1]))
        
        #-----------------TestingData Accuracy---------------------#
        TEST_OUT      = GetValTest(TEST_PHI,W_T_Next) 
        Erms_Test = GetErms(TEST_OUT,TestDataAct)
        L_Erms_Test.append(float(Erms_Test.split(',')[1]))
       
    
    
    # In[ ]:
    
    print ('-------------------------Logistical Regression---------------------------')
    
    print ('----------------------Gradient Descent Solution--------------------------')
    print ("Error Training   = " + str(np.around(min(L_Erms_TR),5)))
    print ("Error Validation = " + str(np.around(min(L_Erms_Val),5)))
    print ("Error Testing    = " + str(np.around(min(L_Erms_Test),5)))
    
print ('----------------------Human observed concatenation--------------------------')
human_concat=logistics(target_human_numpy,numpy_matrix_transpose,target_human_numpy)
print ('----------------------Human observed subtraction----------------------------')
human_sub=logistics(target_human_numpy,numpy_matrix_sub_transpose,target_human_numpy)
print ('----------------------GSC dataset concatenation-----------------------------')
gsc_concat=logistics(target_gsc_numpy,numpy_matrix_transpose_gsc,target_gsc_numpy)
print ('-----------------------GSC Dataset subtraction------------------------------')
human_concat=logistics(target_gsc_numpy,numpy_matrix_transpose_sub_gsc,target_gsc_numpy)
 