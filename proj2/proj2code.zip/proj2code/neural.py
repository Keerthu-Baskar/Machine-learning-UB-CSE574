
from sklearn.cluster import KMeans
import pandas as pd
import numpy as np
import csv
import math
import matplotlib.pyplot
from matplotlib import pyplot as plt

diff_pair=r'\diffn_pairs.csv'
same_pair=r'\same_pairs.csv'

def dataset(samediffpair,datatotake=0,type='default'):
    human_folder=r'HumanObserved-Features-Data'
    gsc_folder=r'GSC-Features-Data'
    human_features=r'\HumanObserved-Features-Data.csv'
    gsc_features=r'\GSC-Features.csv'
    
    if(type=='HumanObserved'):
        folder=human_folder
        file=human_features
    else:
        folder=gsc_folder
        file=gsc_features
    
    #read files
    readfromfile=pd.read_csv(folder+file)
    samepairdata=pd.read_csv(folder+samediffpair)
    
    if(datatotake>1):
        samepairdata=samepairdata.sample(n=datatotake)
    
    #get data for image A
    imgA=pd.merge(samepairdata,readfromfile,left_on='img_id_A',right_on='img_id',how='left')
    imgA.drop(imgA.columns[2:5],axis=1,inplace=True)
        
    #get data for image B
    imgB=pd.merge(samepairdata,readfromfile,left_on='img_id_B',right_on='img_id',how='left')    
    target=imgB[['img_id_B','target']]
    
    imgB.drop(imgB.columns[0],axis=1,inplace=True)
    imgB.drop(imgB.columns[1:4],axis=1,inplace=True)
    
    #merge image A, image B and target data
    finalmerged=pd.merge(imgA,imgB.drop_duplicates(),on='img_id_B',how='left')
    finalmerged=pd.merge(finalmerged,target.drop_duplicates(),on='img_id_B',how='left')

    return finalmerged

def data_method(method):
        
    same_writer=dataset(same_pair,datatotake=0,type=method)
    diff_writer=dataset(diff_pair,datatotake=791,type=method)
    entireset=same_writer.append(diff_writer,ignore_index=True)
    entireset=entireset.reindex(np.random.permutation(entireset.index))
    entireset.sort_index(inplace=True)    
    return entireset;

method='HumanObserved'
human=data_method(method)

method='gsc'
gsc=data_method(method)


#**** human observed*****
#create target set from dataframe
target_human=human['target']
target_human_numpy=target_human.as_matrix() #target value for human
#drop img columns and target from dataframe
human=human.drop(columns=['img_id_A','img_id_B','target'])
#save dataframe as numpy matrix
numpy_matrix=human.as_matrix()
numpy_matrix_transpose=numpy_matrix.transpose() #concatenated tranposed features data

#split numpy array and substract values
a,b=np.hsplit(numpy_matrix,2)
c=np.subtract(b,a)
#save as numpy matrix tranpose
numpy_matrix_sub_transpose=np.transpose(c) #subtracted tranposed features data



method='gsc'
gsc=data_method(method)

#*****GSC dataset******
#create target set from dataframe
target_gsc=gsc['target']
target_gsc_numpy=target_gsc.as_matrix() #target values for gsc
#drop img columns and target from dataframe
gsc=gsc.drop(columns=['img_id_A','img_id_B','target'])
gsc_for_sub=gsc
gsc_for_sub=gsc_for_sub.as_matrix()
#drop columns*********
gsctest=gsc.loc[:,(gsc!=0).any(axis=0)]
#convert data frame to numpy
#*********end drop columns*******
#save dataframe as numpy matrix
numpy_matrix_gsc=gsctest.as_matrix()
numpy_matrix_transpose_gsc=numpy_matrix_gsc.transpose() #concatenated transposed features data

#split numpy array and substract values
x,y=np.hsplit(gsc_for_sub,2)
z=np.subtract(y,x)
#drop columns*********
test1=pd.DataFrame(z)
test1=test1.loc[:,(test1!=0).any(axis=0)]
#convert data frame to numpy
test2=test1.as_matrix()
#*********end drop columns*******
#save as numpy matrix transpose
numpy_matrix_transpose_sub_gsc=np.transpose(test2) #subtracted tranposed features data

#***************NEURAL NETWORK**************************

#human=human.append(target_human, ignore_index=true)
import pandas as pd



# Create first network with Keras
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dense, Activation, Dropout
from keras.callbacks import EarlyStopping, TensorBoard
import numpy
# fix random seed for reproducibility
seed = 7
validation_data_split = 0.2
tb_batch_size = 10
early_patience = 100
numpy.random.seed(seed)

# split into input (X) and output (Y) variables
X = human.as_matrix()
Y = target_human.as_matrix()

def neural(X,Y):
    tensorboard_cb   = TensorBoard(log_dir='logs', batch_size= tb_batch_size, write_graph= True)
    earlystopping_cb = EarlyStopping(monitor='val_loss', verbose=1, patience=early_patience, mode='min')
    
    # create model
    model = Sequential()
    model.add(Dense(100, input_dim=inp, init='uniform', activation='relu'))
    model.add(Dense(200, init='uniform', activation='relu'))
    model.add(Dense(300, init='uniform', activation='relu'))
    model.add(Dense(1, init='uniform', activation='sigmoid'))
    # Compile model
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    # Fit the model
    history=model.fit(X, Y, nb_epoch=10000, batch_size=5,  verbose=2, validation_split=validation_data_split, callbacks = [tensorboard_cb,earlystopping_cb])
    # calculate predictions
    predictions = model.predict(X)
    
    
    
    get_ipython().run_line_magic('matplotlib', 'inline')
    df = pd.DataFrame(history.history)
    df.plot(subplots=True, grid=True, figsize=(10,10))
inp=18
human_concat=neural(human.as_matrix(),target_human.as_matrix())
inp=9
human_sub=neural(c,target_human.as_matrix())
inp=1022
gsc_concat=neural(gsc.as_matrix(),target_gsc.as_matrix())
inp=511
gsc_sub=neural(z,target_gsc.as_matrix())