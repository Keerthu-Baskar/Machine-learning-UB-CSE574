# -*- coding: utf-8 -*-
"""
Created on Thu Oct  4 20:43:55 2018

@author: harip
"""


# coding: utf-8

# In[5]:


from sklearn.cluster import KMeans
import numpy as np
import csv
import math
import matplotlib.pyplot
from matplotlib import pyplot as plt


# In[6]:


maxAcc = 0.0
maxIter = 0
#Lambda regularization for closed for solution
C_Lambda = 0.03
TrainingPercent = 80 #80% of data are taken for training the model
ValidationPercent = 10 #10% of data is taken for validating the model
TestPercent = 10 #10% of data is taken to test the model
M = [1,10,100,1000] #I have given M value in list to printout a graph for different M value
PHI = []
IsSynthetic = False


# In[158]:


def GetTargetVector(filePath):
    #create a list to store the training data
    input_data = []
    #open the file in read update mode
    with open(filePath, 'rU') as input_file:
        #read the file and store each row in an array appending to previous one
        reader = csv.reader(input_file)
        for row in reader:  
            input_data.append(int(row[0]))
    #print("Raw Training Generated..")
    return input_data

def GenerateRawData(filePath, IsSynthetic):    
    dataMatrix = [] 
    #creating data matrix
    # first create a row list and append each row in the list
    #then append all these row list into datamatrix list
    #the final output of datamatrix is a list of list of shape 46x69623
    with open(filePath, 'rU') as fi:
        reader = csv.reader(fi)
        for row in reader:
            dataRow = []
            for column in row:
                dataRow.append(float(column))
            dataMatrix.append(dataRow)  
       
    
    # here we delete the columns that has zero value in the data.
    #If a value of a column is zero the determinant will become zero and matrix multiplication cant be done
    #so ignore zero columns from the data
    #the datamatrix here is 41x69623 shape
    if IsSynthetic == False :
        dataMatrix = np.delete(dataMatrix, [5,6,7,8,9], axis=1)
    dataMatrix = np.transpose(dataMatrix)  
    #print ("Data Matrix Generated..")
    return dataMatrix

#taking 80% of training target value and creating a list of shape (55699,)
def GenerateTrainingTarget(rawTraining,TrainingPercent = 80):
    TrainingLen = int(math.ceil(len(rawTraining)*(TrainingPercent*0.01)))
    t           = rawTraining[:TrainingLen]
    t1=np.transpose(t)
    #print(str(TrainingPercent) + "% Training Target Generated..")
    return t

#taking 80% of training data value and creating a matrix
def GenerateTrainingDataMatrix(rawData, TrainingPercent = 80):
    T_len = int(math.ceil(len(rawData[0])*0.01*TrainingPercent))
    d2 = rawData[:,0:T_len]
    
    #print(str(TrainingPercent) + "% Training Data Generated..")
    return d2
#10% of data to create validation data set and test dataset for input value
def GenerateValData(rawData, ValPercent, TrainingCount): 
    valSize = int(math.ceil(len(rawData[0])*ValPercent*0.01))
    V_End = TrainingCount + valSize
    dataMatrix = rawData[:,TrainingCount+1:V_End]
    #print (str(ValPercent) + "% Val Data Generated..")  
    return dataMatrix

#10% of data to create validation data set and test dataset of target value
def GenerateValTargetVector(rawData, ValPercent, TrainingCount): 
    valSize = int(math.ceil(len(rawData)*ValPercent*0.01))
    V_End = TrainingCount + valSize
    t =rawData[TrainingCount+1:V_End]
    #print (str(ValPercent) + "% Val Target Data Generated..")
    return t

def GenerateBigSigma(Data, MuMatrix,TrainingPercent,IsSynthetic):
    BigSigma    = np.zeros((len(Data),len(Data)))
    #BigSigma will give an array of size 41x41
    #np.zeros will Return an array of zeros with shape and type of input.
    DataT       = np.transpose(Data)
    #after the above line the shape of dataT is 69623x41
    #taking 10% of data (41x69623) which is 10% of 69623 = 55699
    TrainingLen = math.ceil(len(DataT)*(TrainingPercent*0.01))
    #training len is 55699        
    varVect     = []
    for i in range(0,len(DataT[0])):
        #for 0 to 69623
        vct = []
        for j in range(0,int(TrainingLen)):
            #for 0 to 55699
            vct.append(Data[i][j])    
        varVect.append(np.var(vct))
        # Data shape is 41x69623
        #vvct is a list of shape 55699
        #varVect is a list of shape 41
        
    for j in range(len(Data)):
        BigSigma[j][j] = varVect[j]
        #BigSigma is an array of shape is 41x41
        
    if IsSynthetic == True:
        BigSigma = np.dot(3,BigSigma)
    else:
        BigSigma = np.dot(200,BigSigma)
    ##print ("BigSigma Generated..")
    return BigSigma

def GetScalar(DataRow,MuRow, BigSigInv): 
    #this function is to generate the scalar value of gaussian equation
    #Mu vector minus x vector is stored in R
    #BigSigma is multiplied with R inverse, which is mu-x inverse
    #now both results are multiplied
    #this is according to the equation e power minus 1/2 * (X-Mu) * bigSigma * (X-Mu) transpose
    #here X is a vector of size 1x41, Mu is 41x1, Big Sigma is 41X41.
    #By multiplying these we get a scalar value. 
    #this method does not calculate the e power and 1/2 in the equation.
    R = np.subtract(DataRow,MuRow)
    T = np.dot(BigSigInv,np.transpose(R))  
    L = np.dot(R,T)
    #R shape is (41,)
    #T shape is (41,)
    #L shape is () which is scalar
    return L

def GetRadialBasisOut(DataRow,MuRow, BigSigInv):    
    #this method is to calculate the e power and 1/2 in the gaussian equation.
    #(x-Mu) * BigSigma * (x-Mu) transpose gives scalar value in GetScalar method
    #GetRadialBasisOut will do the e power scalar value  and then multiply with 1/2
    phi_x = math.exp(-0.5*GetScalar(DataRow,MuRow,BigSigInv))
    return phi_x

def GetPhiMatrix(Data, MuMatrix, BigSigma, TrainingPercent = 80):
    #MuMatrix is an array of 10x41
    DataT = np.transpose(Data)
    #DataT is an array of shape 69623x41
    TrainingLen = math.ceil(len(DataT)*(TrainingPercent*0.01))    
    #trainingLen value is 55699   
    PHI = np.zeros((int(TrainingLen),len(MuMatrix))) 
    #PHI is an array of 55699x10
    BigSigInv = np.linalg.inv(BigSigma)
    #finding inverse of BigSigma
    #BigSigma is an array of size 10x10
    for  C in range(0,len(MuMatrix)):
        for R in range(0,int(TrainingLen)):
            PHI[R][C] = GetRadialBasisOut(DataT[R], MuMatrix[C], BigSigInv)
            #PHI is an array of shape 55699x10
    #print ("PHI Generated..")
    return PHI

def GetWeightsClosedForm(PHI, T, Lambda):
    #generating weights of the closed form solution the formula is
    #w= (phi transpose * phi)inverse * phi inverse * target vector
    
    #Phi is an array of shape (55699x10)
    #get identity matrix of PHI length(10)
    Lambda_I = np.identity(len(PHI[0]))
    #Lamba is an identity matrix array of shape 10x10
    for i in range(0,len(PHI[0])):
        Lambda_I[i][i] = Lambda
    print("Lambda")
    print(Lambda_I[i][i])
    PHI_T       = np.transpose(PHI)
    #array of shape (10x55699)
    PHI_SQR     = np.dot(PHI_T,PHI)
    #array of shape 10x10
    PHI_SQR_LI  = np.add(Lambda_I,PHI_SQR)
    #array of shape 10x10
    PHI_SQR_INV = np.linalg.inv(PHI_SQR_LI)
    #array of shape 10x10
    INTER       = np.dot(PHI_SQR_INV, PHI_T)
    #array of shape 10x55699
    W           = np.dot(INTER, T)
    #T is an array of shape (55699,) so multiply with inter (10x55699)
    #array of shape (10,)
    ##print ("Training Weights Generated..")
    return W
 

def GetValTest(VAL_PHI,W):
    Y = np.dot(W,np.transpose(VAL_PHI))
    ##print ("Test Out Generated..")
    return Y

#Erms is calculating the error, how accurate the model learned
def GetErms(VAL_TEST_OUT,ValDataAct):
    sum = 0.0
    t=0
    accuracy = 0.0
    counter = 0
    val = 0.0
    for i in range (0,len(VAL_TEST_OUT)):
        #minus the predicted value from the actual value from target set and divide by the length of predicted value
        sum = sum + math.pow((ValDataAct[i] - VAL_TEST_OUT[i]),2)
        if(int(np.around(VAL_TEST_OUT[i], 0)) == ValDataAct[i]):
            counter+=1
    accuracy = (float((counter*100))/float(len(VAL_TEST_OUT)))
    ##print ("Accuracy Generated..")
    ##print ("Validation E_RMS : " + str(math.sqrt(sum/len(VAL_TEST_OUT))))
    return (str(accuracy) + ',' +  str(math.sqrt(sum/len(VAL_TEST_OUT))))


# ## Fetch and Prepare Dataset

# In[127]:


RawTarget = GetTargetVector('Querylevelnorm_t.csv')
RawData   = GenerateRawData('Querylevelnorm_X.csv',IsSynthetic)


# ## Prepare Training Data

# In[128]:

#calling the method to create the training dataset and target dataset
TrainingTarget = np.array(GenerateTrainingTarget(RawTarget,TrainingPercent))
TrainingData   = GenerateTrainingDataMatrix(RawData,TrainingPercent)



# ## Prepare Validation Data

# In[129]:

#calling the methods to create the validation dataset and validation target dataset
ValDataAct = np.array(GenerateValTargetVector(RawTarget,ValidationPercent, (len(TrainingTarget))))
ValData    = GenerateValData(RawData,ValidationPercent, (len(TrainingTarget)))



# ## Prepare Test Data

# In[130]:

#calling the method to create the test dataset and target test set
TestDataAct = np.array(GenerateValTargetVector(RawTarget,TestPercent, (len(TrainingTarget)+len(ValDataAct))))
TestData = GenerateValData(RawData,TestPercent, (len(TrainingTarget)+len(ValDataAct)))



# ## Closed Form Solution [Finding Weights using Moore- Penrose pseudo- Inverse Matrix]

# In[155]:


ErmsArr = []
AccuracyArr = []

#create clusters for the number of basis function
#calculate the Mu, Sigma, Bigsigma, Weights, Phi value
for i in M:
    kmeans = KMeans(n_clusters=i, random_state=0).fit(np.transpose(TrainingData))
    Mu = kmeans.cluster_centers_

    BigSigma     = GenerateBigSigma(RawData, Mu, TrainingPercent,IsSynthetic)
    print("BigSigma")
    print(BigSigma.shape)
    TRAINING_PHI = GetPhiMatrix(RawData, Mu, BigSigma, TrainingPercent)
    print("TRAINING_PHI")
    print(TRAINING_PHI.shape)
    W            = GetWeightsClosedForm(TRAINING_PHI,TrainingTarget,(C_Lambda)) 
    print("W")
    print(W.shape)
    TEST_PHI     = GetPhiMatrix(TestData, Mu, BigSigma, 100) 
    print("TEST_PHI")
    print(TEST_PHI.shape)
    VAL_PHI      = GetPhiMatrix(ValData, Mu, BigSigma, 100)
    print("VAL_PHI")
    print(VAL_PHI.shape)
    TR_TEST_OUT  = GetValTest(TRAINING_PHI,W)
    VAL_TEST_OUT = GetValTest(VAL_PHI,W)
    TEST_OUT     = GetValTest(TEST_PHI,W)


    TrainingAccuracy   = str(GetErms(TR_TEST_OUT,TrainingTarget))
    ValidationAccuracy = str(GetErms(VAL_TEST_OUT,ValDataAct))
    TestAccuracy       = str(GetErms(TEST_OUT,TestDataAct))
    ErmsArr.append(float(TrainingAccuracy.split(',')[1]))

# In[156]:

print("Mu")
print(Mu.shape)
#print(BigSigma.shape)
#print(TRAINING_PHI.shape)
#print(W.shape)
#print(VAL_PHI.shape)
#print(TEST_PHI.shape)


# ## Finding Erms on training, validation and test set 

# In[159]:

#Training Phi result array shape is (55699,10).
#W resultant array shape is (10,)
#GetValTest will return dot product of them so the resultant will be (55699,)
TR_TEST_OUT  = GetValTest(TRAINING_PHI,W)
VAL_TEST_OUT = GetValTest(VAL_PHI,W)
TEST_OUT     = GetValTest(TEST_PHI,W)


TrainingAccuracy   = str(GetErms(TR_TEST_OUT,TrainingTarget))
ValidationAccuracy = str(GetErms(VAL_TEST_OUT,ValDataAct))
TestAccuracy       = str(GetErms(TEST_OUT,TestDataAct))


# In[160]:


print ('UBITname      = kbaskara')
print ('Person Number = 50288944')
print ('----------------------------------------------------')
print ("------------------LeToR Data------------------------")
print ('----------------------------------------------------')
print ("-------Closed Form with Radial Basis Function-------")
print ('----------------------------------------------------')
print ("M = 10 \nLambda = 0.3")
print ("E_rms Training   = " + str(float(TrainingAccuracy.split(',')[1])))
print ("E_rms Validation = " + str(float(ValidationAccuracy.split(',')[1])))
print ("E_rms Testing    = " + str(float(TestAccuracy.split(',')[1])))
#printing the accuracy for closed form solution
print ("Training Accuracy  = " + str(float(TrainingAccuracy.split(',')[0])))
print ("Validation Accuracy = " + str(float(ValidationAccuracy.split(',')[0])))
print ("Testing Accuracy   = " + str(float(TestAccuracy.split(',')[0])))

plt.plot(M,ErmsArr)
plt.ylabel("Training Accuracy")
plt.xlabel("M in closed form solution")
plt.show()


# ## Gradient Descent solution for Linear Regression

# In[138]:


print ('----------------------------------------------------')
print ('--------------Please Wait for 2 mins!----------------')
print ('----------------------------------------------------')


# In[ ]:

#random initialization of weights
W_Now        = np.dot(220, W)
La           = 2
learningRate = 0.01
L_Erms_Val   = []
L_Erms_TR    = []
L_Erms_Test  = []
W_Mat        = []

for i in range(0,400):
    
    #update the weights iteratively. the new weights is addition to the old weight
    #the calculation below is done according to the formula of weight update in SGD
    # the terms include weights of previous run and the learning rate
    #print ('---------Iteration: ' + str(i) + '--------------')
    Delta_E_D     = -np.dot((TrainingTarget[i] - np.dot(np.transpose(W_Now),TRAINING_PHI[i])),TRAINING_PHI[i])
    La_Delta_E_W  = np.dot(La,W_Now)
    Delta_E       = np.add(Delta_E_D,La_Delta_E_W)    
    Delta_W       = -np.dot(learningRate,Delta_E)
    W_T_Next      = W_Now + Delta_W
    W_Now         = W_T_Next
    
    #-----------------TrainingData Accuracy---------------------#
    #method calling for getting the training dataset and the erms value for that set
    TR_TEST_OUT   = GetValTest(TRAINING_PHI,W_T_Next) 
    Erms_TR       = GetErms(TR_TEST_OUT,TrainingTarget)
    L_Erms_TR.append(float(Erms_TR.split(',')[1]))
    
    #-----------------ValidationData Accuracy---------------------#
    #method calling for getting the validation dataset and the erms value for that set
    VAL_TEST_OUT  = GetValTest(VAL_PHI,W_T_Next) 
    Erms_Val      = GetErms(VAL_TEST_OUT,ValDataAct)
    L_Erms_Val.append(float(Erms_Val.split(',')[1]))
    
    #-----------------TestingData Accuracy---------------------#
    #method calling for getting the testing dataset and the erms value for that set
    TEST_OUT      = GetValTest(TEST_PHI,W_T_Next) 
    Erms_Test = GetErms(TEST_OUT,TestDataAct)
    L_Erms_Test.append(float(Erms_Test.split(',')[1]))


# In[ ]:


print ('----------Gradient Descent Solution--------------------')
print ("M = 10 \nLambda  = 2 \neta=0.01")
print ("E_rms Training   = " + str(np.around(min(L_Erms_TR),5)))
print ("E_rms Validation = " + str(np.around(min(L_Erms_Val),5)))
print ("E_rms Testing    = " + str(np.around(min(L_Erms_Test),5)))
#printing the accuracy
print("Training Accuracy = "+ str(float(Erms_TR.split(',')[0])))
print("Validation Accuracy = "+ str(float(Erms_Val.split(',')[0])))
print("Testing Accuracy = "+ str(float(Erms_Test.split(',')[0])))

plt.plot(M,ErmsArr)
plt.ylabel("Training Accuracy")
plt.xlabel("M in SGD")
plt.show()

M1=[0.1,0.01,0.001,0.0001,0.00001]
a1=[0.56,0.56,13.12,53.6,70.6] 
plt.plot(M1,a1)
plt.ylabel("training accuracy")
plt.xlabel("learning rate")
plt.show()

M2=[0.01,0.001,0.0001]
a2=[0.58,13.12,53.6] 
plt.plot(M2,a2)
plt.ylabel("training accuracy")
plt.xlabel("Lambda regularization for SGD")
plt.show()