
# coding: utf-8

# ## Load MNIST on Python 3.x

# In[3]:


import pickle
import gzip
import numpy as np


# In[4]:


filename = 'mnist.pkl.gz'
f = gzip.open(filename, 'rb')
training_data, validation_data, test_data = pickle.load(f, encoding='latin1')
training_data_0=training_data[0]
training_data_1=training_data[1]
test_data_0=test_data[0]
test_data_1=test_data[1]
validation_data_0=validation_data[0]
validation_data_1=validation_data[1]
f.close()
# ## Load USPS on Python 3.x

# In[8]:


from PIL import Image
import os



# In[9]:


USPSMat  = []
USPSTar  = []
curPath  = 'USPSdata/USPSdata/Numerals'
savedImg = []

for j in range(0,10):
    curFolderPath = curPath + '/' + str(j)
    imgs =  os.listdir(curFolderPath)
    for img in imgs:
        curImg = curFolderPath + '/' + img
        if curImg[-3:] == 'png':
            img = Image.open(curImg,'r')
            img = img.resize((28, 28))
            savedImg = img
            imgdata = (255-np.array(img.getdata()))/255
            USPSMat.append(imgdata)
            USPSTar.append(j)

test_data_0=np.asarray(test_data_0)
test_data_1=np.asarray(test_data_1)
USPSMat=np.asarray(USPSMat)
USPSTar=np.asarray(USPSTar)



print("Data preprocessing done")

#***************NEURAL NETWORK**************************

import pandas as pd



# Create first network with Keras
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Activation, Dropout
from keras.callbacks import EarlyStopping, TensorBoard
from sklearn.metrics import accuracy_score
import numpy
import keras
# fix random seed for reproducibility
seed = 7
validation_data_split = 0.2
tb_batch_size = 10
early_patience = 100
numpy.random.seed(seed)

num_classes=10
image_vector_size=28*28
image_size=784

x_train=training_data_0
y_train=training_data_1
x_test=test_data_0
y_test=test_data_1

x_train = x_train.reshape(x_train.shape[0], image_vector_size)
x_test = x_test.reshape(x_test.shape[0], image_vector_size)
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)


#one hot encoding

data1=USPSTar
data=np.array(data1)
encoded1=keras.utils.to_categorical(data1)


tensorboard_cb   = TensorBoard(log_dir='logs', batch_size= tb_batch_size, write_graph= True)
earlystopping_cb = EarlyStopping(monitor='val_loss', verbose=1, patience=early_patience, mode='min')

model=Sequential()
model.add(Dense(units=32, activation='sigmoid', input_shape=(image_size,)))
model.add(Dense(units=num_classes, activation='softmax'))


model.compile(optimizer='adam', loss='categorical_crossentropy',metrics=['accuracy'])

history = model.fit(x_train, y_train, batch_size=20, epochs=10, verbose=2,validation_split=.1, callbacks = [tensorboard_cb,earlystopping_cb])
loss,accuracy = model.evaluate(x_test, y_test, verbose=2)

predictions = model.predict(x_test)
predictions = np.argmax(predictions, axis=1)
neural_mnist=predictions
y_test=np.argmax(y_test,axis=1)

print("--------------------NEURAL NETWORKS--------------------") 

print("Loss for MNIST testdata:", loss)
print("Accuracy for MNIST testdata:",accuracy)

print("-------------------------------------------------------")
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(y_test,predictions, labels=None, sample_weight=None)
print("confusion matrix for MNIST dataset")
print(cm)

'''
get_ipython().run_line_magic('matplotlib', 'inline')
df = pd.DataFrame(history.history)
df.plot(subplots=True, grid=True, figsize=(10,10))
'''
print("-------------------------------------------------------")

loss,accuracy = model.evaluate(USPSMat, encoded1, verbose=2)

predictions = model.predict(USPSMat)
neural_usps=predictions
predictions = np.argmax(predictions, axis=1)
encoded1=np.argmax(encoded1,axis=1)

'''
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(encoded,predictions)
''' 
print("Loss for USPS testdata:", loss)
print("Accuracy for USPS testdata:",accuracy)    
print("-------------------------------------------------------")
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(encoded1,predictions, labels=None, sample_weight=None)
print("confusion matrix for USPS dataset")
print(cm)

'''    
get_ipython().run_line_magic('matplotlib', 'inline')
df = pd.DataFrame(history.history)
df.plot(subplots=True, grid=True, figsize=(10,10))
'''
print("-------------------------------------------------------")

#***************Random forest**************************

# SVM & RandomForest
import numpy as np
from sklearn.svm import SVC
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import fetch_mldata
from sklearn.metrics import accuracy_score
print("-------------------RANDOM FOREST-----------------------")

#RandomForestClassifier for MNIST
classifier2 = RandomForestClassifier(n_jobs=-1, n_estimators=10);
classifier2.fit(training_data_0, training_data_1)
prediction=classifier2.predict(test_data_0)
random_mnist=prediction
accuracy = accuracy_score(test_data_1,prediction)
print("Random forest accuracy for MNIST dataset:",accuracy)
print("-------------------------------------------------------")
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(test_data_1,prediction, labels=None, sample_weight=None)
print("confusion matrix for MNIST dataset")
print(cm)
print("-------------------------------------------------------")
prediction=classifier2.predict(USPSMat)
random_usps=prediction
accuracy = accuracy_score(USPSTar,prediction)
print("Random forest accuracy for USPS dataset:",accuracy)
print("-------------------------------------------------------")

from sklearn.metrics import confusion_matrix
cm=confusion_matrix(USPSTar,prediction, labels=None, sample_weight=None)
print("confusion matrix for USPS dataset")
print(cm)


print("-------------------------------------------------------")
#***************SVM**************************

# SVM & RandomForest
import numpy as np
from sklearn.svm import SVC
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import fetch_mldata
from sklearn.metrics import accuracy_score
print("-----------------------SVM-----------------------------")
# SVM for MNIST dataset
classifier1 = svm.SVC(kernel='rbf', C=2, gamma = 0.05, cache_size=1000,probability=False);
classifier1.fit(training_data_0, training_data_1)
prediction=classifier1.predict(test_data_0)
svm_mnist=prediction
accuracy=accuracy_score(test_data_1, prediction)
print ("SVM accuracy for MNIST dataset:",accuracy)
print("-------------------------------------------------------")
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(test_data_1,prediction, labels=None, sample_weight=None)
print("confusion matrix for MNIST dataset")
print(cm)

print("-------------------------------------------------------")
prediction=classifier1.predict(USPSMat)
svm_usps=prediction
accuracy=accuracy_score(USPSTar, prediction)
print ("SVM accuracy for USPS dataset:",accuracy)
print("-------------------------------------------------------")
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(USPSTar,prediction, labels=None, sample_weight=None)
print("confusion matrix for USPS dataset")
print(cm)

print("-------------------------------------------------------")

#-----------------logistics regression--------------------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.sparse

print("------------------LOGISTIC REGRESSION------------------")
def getLoss(w,x,y,lam):
    m = x.shape[0] 
    y_mat = oneHotIt(y) 
    scores = np.dot(x,w) 
    prob = softmax(scores) 
    loss = (-1 / m) * np.sum(y_mat * np.log(prob)) + (lam/2)*np.sum(w*w)
    grad = (-1 / m) * np.dot(x.T,(y_mat - prob)) + lam*w 
    return loss,grad

def oneHotIt(Y):
    m = Y.shape[0]
    #Y = Y[:,0]   
    OHX = scipy.sparse.csr_matrix((np.ones(m), (Y, np.array(range(m)))))
    OHX = np.array(OHX.todense()).T
    return OHX

'''
x_test = x_test.reshape(x_test.shape[0], image_vector_size)
y_test = keras.utils.to_categorical(y_test, num_classes)
'''

def softmax(z):
    z -= np.max(z)
    sm = (np.exp(z).T / np.sum(np.exp(z),axis=1)).T
    return sm



def getProbsAndPreds(test_data_0):
    probs = softmax(np.dot(test_data_0,w))
    preds = np.argmax(probs,axis=1)
    return probs,preds


def getAccuracy(test_data_0,test_data_1):
    prob,prede = getProbsAndPreds(test_data_0)
    accuracy = sum(prede == test_data_1)/(float(len(test_data_1)))
    return accuracy

#---MAIN loop
    

w = np.zeros([training_data_0.shape[1],len(np.unique(training_data_1))])
lam = 0.01
iterations = 1000
learningRate = 0.01
losses = []
for i in range(0,iterations):
    loss,grad = getLoss(w,training_data_0,training_data_1,lam)
    losses.append(loss)
    w = w - (learningRate * grad)
print ("loss")
print (loss)
plt.plot(losses)
print("-------------------------------------------------------")
#print ('Training Accuracy for MNIST dataset: ', getAccuracy(training_data_0,training_data_1))
print ('Test Accuracy for MNIST dataset: ', getAccuracy(test_data_0,test_data_1))
print("-------------------------------------------------------")
print ('Test Accuracy for USPS dataset: ', getAccuracy(USPSMat,USPSTar))
print("-------------------------------------------------------")
predb1,pred1=getProbsAndPreds(test_data_0)
logistic_mnist=pred1
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(test_data_1,pred1, labels=None, sample_weight=None)
print("Confusion matrix for MNIST dataset")
print(cm)
print("-------------------------------------------------------")

predb1,pred1=getProbsAndPreds(USPSMat)
logistic_usps=pred1
from sklearn.metrics import confusion_matrix
cm=confusion_matrix(USPSTar,pred1, labels=None, sample_weight=None)
print("confusion matrix for USPS dataset")
print(cm)


print("-------------------------------------------------------")

from collections import Counter
ensembleList=[]      
def ensembleClassifier(test_data_1, neural_mnist, random_mnist, svm_mnist, logistic_mnist ):
    for i in range(len(test_data_1)):
        temp=[]
        temp.append(neural_mnist[i])
        temp.append(random_mnist[i])
        temp.append(svm_mnist[i])
        temp.append(logistic_mnist[i])
        a,b= Counter(temp).most_common(1)[0]
        ensembleList.append(a)
    return accuracy_score(ensembleList, test_data_1)

EnsembleAccuracy = ensembleClassifier(test_data_1, neural_mnist, random_mnist, svm_mnist, logistic_mnist)
print("-------------------COMBINED MODEL----------------------")
print("Combined model accuracy for MNIST:", EnsembleAccuracy)
print("-------------------------------------------------------")      
   

'''
#-----ensemble with sklearn
print("-------------------COMBINED MODEL----------------------")
from sklearn.ensemble import VotingClassifier
from sklearn.linear_model import LogisticRegression

rf=RandomForestClassifier()
lr=LogisticRegression()
svm=SVC(kernel='rbf',degree=2)
evc=VotingClassifier(estimators=[('lr',lr),('rf',rf),('svm',svm)],voting='hard')
evc.fit(training_data_0,training_data_1)
a=evc.score(test_data_0, test_data_1)

print("Combined model accuracy:",a)
print("-------------------------------------------------------")
'''