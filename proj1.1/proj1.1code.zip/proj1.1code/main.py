
# coding: utf-8

# ## Logic Based FizzBuzz Function [Software 1.0]

# In[25]:


import pandas as pd

def fizzbuzz(n):
    
    # Logic Explanation
    if n % 3 == 0 and n % 5 == 0:
        return 'FizzBuzz'
    elif n % 3 == 0:
        return 'Fizz'
    elif n % 5 == 0:
        return 'Buzz'
    else:
        return 'Other'


# ## Create Training and Testing Datasets in CSV Format

# In[1]:


def createInputCSV(start,end,filename):
    
    # Why list in Python?
    #List is a type of data structure used in python.
    inputData   = []
    outputData  = []
    
    # Why do we need training Data?
    # Training data is needed for the model to work accurately. The model will learn the logic to be interpreted from the training data. So a considerable amount or size of training data is important to make the model work accurately.
    for i in range(start,end):
        inputData.append(i)
        outputData.append(fizzbuzz(i))
    
    # Why Dataframe?
    #When dealing with large set of data, consider a health report of all patients in global hospital. If we need to get some information from the data, then we need to write big code for that. Instead we use panda and load this data(import panda and read the data file) as data frame. It looks like a table or a data structure. We just write simple line of code to get the information from the data. Apart from retrieving data we can perform many arithmetic operations also.
    dataset = {}
    dataset["input"]  = inputData
    dataset["label"] = outputData
    
    # Writing to csv
    pd.DataFrame(dataset).to_csv(filename)
    
    print(filename, "Created!")


# ## Processing Input and Label Data

# In[27]:
    #data mungling or wrangling?
    #Few missing information or mistakes in data is called data mungling. Example, if a data is given in excel and we load that in data frame. Then for missing fields of excel the data frame shows as NaN. So we have to take care of cleaning the data before next step to avoid minor changes in output.

def processData(dataset):
    
    # Why do we have to process?
    #After the data is read from file and the NaN are rectified, we have to process the data. There might be few fields in the data which are categorical. Like the gender, country etc. We have to convert it into numerical value which is also called encoding the categorical values. In our case we have to categorize the fizz, buzz, fizzbuzz and others by numerical value.
    data   = dataset['input'].values
    labels = dataset['label'].values
    
    processedData  = encodeData(data)
    processedLabel = encodeLabel(labels)
    
    return processedData, processedLabel


# In[28]:


def encodeData(data):
    
    processedData = []
    
    for dataInstance in data:
        
        # Why do we have number 10?
        #the input when converted to binary is 10 bits
        processedData.append([dataInstance >> d & 1 for d in range(10)])
    
    return np.array(processedData)


# In[29]:


from keras.utils import np_utils

def encodeLabel(labels):
    
    processedLabel = []
    
    for labelInstance in labels:
        if(labelInstance == "FizzBuzz"):
            # Fizzbuzz
            processedLabel.append([3])
        elif(labelInstance == "Fizz"):
            # Fizz
            processedLabel.append([1])
        elif(labelInstance == "Buzz"):
            # Buzz
            processedLabel.append([2])
        else:
            # Other
            processedLabel.append([0])

    return np_utils.to_categorical(np.array(processedLabel),4)


# ## Model Definition

# In[30]:


from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.callbacks import EarlyStopping, TensorBoard
import matplotlib.pyplot as plt

import numpy as np

#size of input(after converting to binary)
input_size = 10
#dropout rate for regularization
drop_out = 0.2
# first layer in hidden layers
first_dense_layer_nodes  = 230
intermediate_dense_layer_node = 100
#output layer(4 because we have 4 categories)
second_dense_layer_nodes = 4

def get_model():
    
    # Why do we need a model?
    # In artificial neural network we use model which will be trained from the data. There are 2 types. We use sequential model here
    #While creating a model we need to specify the type of model. There are 2 types in keras. Sequential and model class used with functional API.
   
    # Why use Dense layer and then activation?
    #Dense layer means a fully connected connected neural network. We first have to define the model name, add layer, then compile the model, do the fit with activation function
    
    # Why use sequential model with layers?
    # sequential model is the simpler one and if we have a set of inputs and ready for processing then we can use sequential. The other functional API model is for giving input when the model is learning from the data. But in sequential case, first the set of inputs are already given to the model later there is not interruption from input until the model completes.
    model = Sequential()
    
    model.add(Dense(first_dense_layer_nodes, input_dim=input_size))
    model.add(Activation('tanh'))
    
    # Why dropout?
    #dropout will nullify or shutdown few neurons. IT is a part of regularization to make the model prevent overfit.
    #model.add(Dropout(drop_out))
    
    #This is second layer of neural network. For second layer we need not specify the input size again. Since there is no more layer we are going to define, this layer is also the output layer
    model.add(Dense(intermediate_dense_layer_node))
    model.add(Activation('tanh'))
    
    model.add(Dense(second_dense_layer_nodes))
    model.add(Activation('sigmoid'))
    # Why Softmax?
    #relu cant be applied to the last layer of the neural network. relu is for intermediate hidden layers. For the last layer softmax can be used
    model.summary()
    
    # Why use categorical_crossentropy?
    #Categorical cross entropy is the loss that the model will try to reduce. For multi class classification like fizz buzz we use categorical cross entropy. For binary classification we use binary cross entropy and for mean square error regression problem we use mse. 
    
    #We need to compile the model to make it ready for training. It is like configuring the model. 
    #There are many optimizers that can be used to change the weights and bias during training. Here we have used adam which is more efficient.
    #We have used categorical cross entropy as loss because we are dealing with a categorical problem. Accuracy is the evaluation metric that we use. 
    #Optimizers are used to decrease the error function. 
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    
    return model


# # <font color='blue'>Creating Training and Testing Datafiles</font>

# In[31]:


# Create datafiles
createInputCSV(101,1001,'training.csv')
createInputCSV(1,101,'testing.csv')


# # <font color='blue'>Creating Model</font>

# In[32]:


model = get_model()


# # <font color = blue>Run Model</font>

# In[33]:

#Training set is the data with which the model is trained. Validation set is separate from training set. This helps in adjusting hyper parameters. During each epoch the model will learn from training set and simultaneously validate from validation set. Based on the difference in output from both, the loss calucation the hyperparameters are changed and weights are adjusted. Validation set is used to avoid overfit in this sense.
validation_data_split = 0.5
#It is the number of times the model will run through the data. Since the data is too large we can divide the data and send it in multiple blocks called batches. For example if we have 100 data and we divide it into 2 batches of size 50. Then it takes 2 iteration to complete one epoch.
num_epochs = 10000
model_batch_size = 128
tb_batch_size = 32
#earlystopping value (a number of epoch for which the model will wait when there is no progree)
early_patience = 100        

#TensorBoard is a visualization tool provided with TensorFlow
#Log_dir – this is the path of directory to save the log files
#Write_graph – this parameter is the visualize the graph in TensorBoard
#Batch_size – this is the batch size to be sent for this histogram computation
tensorboard_cb   = TensorBoard(log_dir='logs', batch_size= tb_batch_size, write_graph= True)
#Early stopping will stop the training to model once the quantity that is monitored shows no improvement. 
#Monitor: it is the quantity to be monitored.
#Patience: it is the number of epochs with no improvement for which the model will wait before stopping.
#Mode: min means the training will stop when the quantity that is getting monitored has stopped decreasing. It takes values as min, max, auto.
earlystopping_cb = EarlyStopping(monitor='val_loss', verbose=1, patience=early_patience, mode='min')


# Read Dataset
dataset = pd.read_csv('training.csv')
# Process Dataset
processedData, processedLabel = processData(dataset)
#Fit: it will train the model based on the number of epoch and other conditions given. This is where training occurs. 
#A callback is the will call the tensorboard and we can get the view on the statistics of the model during training. Here the callback will save the best model when the earlystopping occurs. 
history = model.fit(processedData
                    , processedLabel
                    , validation_split=validation_data_split
                    , epochs=num_epochs
                    , batch_size=model_batch_size
                    , callbacks = [tensorboard_cb,earlystopping_cb]
                   )
plt.plot([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0])
plt.plot([0.1162,0.1233,0.1067,0.1329,0.0013,0.1305,0.0859,0.0435,0.1812,0.2909])
plt.show()




# # <font color = blue>Training and Validation Graphs</font>

# In[34]:


get_ipython().run_line_magic('matplotlib', 'inline')
df = pd.DataFrame(history.history)
df.plot(subplots=True, grid=True, figsize=(10,15))


# # <font color = blue>Testing Accuracy [Software 2.0]</font>

# In[35]:


def decodeLabel(encodedLabel):
    if encodedLabel == 0:
        return "Other"
    elif encodedLabel == 1:
        return "Fizz"
    elif encodedLabel == 2:
        return "Buzz"
    elif encodedLabel == 3:
        return "FizzBuzz"


# In[36]:


wrong   = 0
right   = 0

testData = pd.read_csv('testing.csv')

processedTestData  = encodeData(testData['input'].values)
processedTestLabel = encodeLabel(testData['label'].values)
predictedTestLabel = []

for i,j in zip(processedTestData,processedTestLabel):
    y = model.predict(np.array(i).reshape(-1,10))
    predictedTestLabel.append(decodeLabel(y.argmax()))
    
    if j.argmax() == y.argmax():
        right = right + 1
    else:
        wrong = wrong + 1

print("Errors: " + str(wrong), " Correct :" + str(right))

print("Testing Accuracy: " + str(right/(right+wrong)*100))

# Please input your UBID and personNumber 
testDataInput = testData['input'].tolist()
testDataLabel = testData['label'].tolist()

testDataInput.insert(0, "UBID")
testDataLabel.insert(0, "kbaskara")

testDataInput.insert(1, "personNumber")
testDataLabel.insert(1, "50288944   ")

predictedTestLabel.insert(0, "")
predictedTestLabel.insert(1, "")

output = {}
output["input"] = testDataInput
output["label"] = testDataLabel

output["predicted_label"] = predictedTestLabel

opdf = pd.DataFrame(output)
opdf.to_csv('output.csv')

